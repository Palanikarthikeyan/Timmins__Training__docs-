import pyvisa
import numpy as np
import matplotlib.pyplot as plt
import csv
from datetime import datetime

# --- Configuration ---
SIM_CONFIG_FILE = "oscilloscope.yaml"
VISA_ADDRESS = 'USB::0x0461::0x0113::6062777::INSTR'
REPORT_FILENAME = "test_report.csv"
PLOT_FILENAME = "waveform_plot.png"

# --- Main Test Function ---
def run_device_test_simulation():
    print(f"--- Starting Device Test Simulation ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')}) ---")

    # 1. Control PC (Python + PyVISA) - Resource Manager setup
    try:
        # Use the simulation backend with the specified YAML config
        rm = pyvisa.ResourceManager(f'{SIM_CONFIG_FILE}@sim')
        print("PyVISA Resource Manager initialized with simulation backend.")
    except OSError as e:
        print(f"ERROR: Failed to initialize ResourceManager with pyvisa-sim: {e}")
        return

    scope = None
    try:
        # 2. Test Device (USB Oscilloscope / DMM) - Connect
        scope = rm.open_resource(VISA_ADDRESS)
        scope.timeout = 25000  # Set a generous timeout for simulated operations
        scope.read_termination = '\n' # Ensure correct termination handling
        scope.write_termination = '\n' # Ensure correct termination handling (optional but good practice)

        print(f"Successfully connected to simulated oscilloscope at {VISA_ADDRESS}")

        # Query device identification (SCPI command)
        idn = scope.query("*IDN?")
        print(f"Instrument ID: {idn.strip()}")

        # 3. Device Under Test (Arduino / Raspberry Pi) - Simulate Signal Generation (represented by querying data)
        print("Simulating signal acquisition from DUT...")
        scope.write(":ACQUIRE:STATE ON") # Command to start acquisition on a real scope

        # Get waveform preamble data (scaling factors)
        y_mult = float(scope.query(":WFMOutpre:YMULT?"))
        y_offset = float(scope.query(":WFMOutpre:YOFF?"))
        x_incr = float(scope.query(":WFMOutpre:XINCR?"))
        
        print(f"Waveform Scaling Factors: YMULT={y_mult:.4f}V/div, YOFF={y_offset:.4f}V, XINCR={x_incr:.6f}s")

        # Get the simulated waveform data (SCPI command)
        scope.write(":CURVE?") # Write command
        raw_data_str = scope.read() # Read the response string
        raw_data = np.fromstring(raw_data_str, sep=',') # Convert string to numpy array

        # 4. Control PC (Python) - Data Processing
        voltage_data = (raw_data * y_mult) + y_offset
        time_data = np.arange(0, len(voltage_data) * x_incr, x_incr)

        max_voltage = np.max(voltage_data)
        min_voltage = np.min(voltage_data)
        avg_voltage = np.mean(voltage_data)
        print(f"Data Processed: Max Voltage={max_voltage:.3f}V, Min Voltage={min_voltage:.3f}V, Avg Voltage={avg_voltage:.3f}V")

        # 5. Report/Logs (CSV, Excel, Graphs) - Generate report
        generate_report(max_voltage, min_voltage, avg_voltage, voltage_data, time_data)
        generate_plot(time_data, voltage_data)

    except pyvisa.VisaIOError as e:
        print(f"VISA Error: {e}")
    except ValueError as e:
        print(f"Data Processing Error: {e}. Check if raw data parsing failed.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    finally:
        if scope:
            scope.close()
            print("Simulated oscilloscope connection closed.")
        if rm:
            rm.close()
            print("Resource Manager closed.")
    print("--- Test Simulation Finished ---")


def generate_report(max_v, min_v, avg_v, voltage_data, time_data):
    """Generates a CSV report with key metrics and a sample of raw data."""
    try:
        with open(REPORT_FILENAME, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["Metric", "Value"])
            writer.writerow(["Timestamp", datetime.now().isoformat()])
            writer.writerow(["Max Voltage (V)", f"{max_v:.4f}"])
            writer.writerow(["Min Voltage (V)", f"{min_v:.4f}"])
            writer.writerow(["Average Voltage (V)", f"{avg_v:.4f}"])
            writer.writerow([]) # Blank line for separation
            writer.writerow(["Time (s)", "Voltage (V)"])
            # Write a sample of the data (e.g., first 100 points) to keep report size manageable
            for i in range(min(len(time_data), 100)): 
                writer.writerow([f"{time_data[i]:.6f}", f"{voltage_data[i]:.4f}"])
        print(f"Report saved to {REPORT_FILENAME}")
    except IOError as e:
        print(f"Error saving report: {e}")

def generate_plot(time_data, voltage_data):
    """Generates and saves a plot of the simulated waveform."""
    try:
        plt.figure(figsize=(10, 6))
        plt.plot(time_data, voltage_data)
        plt.title("Simulated Oscilloscope Waveform")
        plt.xlabel("Time (s)")
        plt.ylabel("Voltage (V)")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(PLOT_FILENAME)
        print(f"Waveform plot saved to {PLOT_FILENAME}")
        # plt.show() # Uncomment if you want to display the plot during execution
    except Exception as e:
        print(f"Error generating plot: {e}")

if __name__ == "__main__":
    run_device_test_simulation()

