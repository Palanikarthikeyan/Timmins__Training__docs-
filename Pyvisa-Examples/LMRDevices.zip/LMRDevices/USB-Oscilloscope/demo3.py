import logging
import pyvisa
import numpy as np
import matplotlib.pyplot as plt

pyvisa.log_to_screen()
# The YAML configuration file for the simulation
sim_config = "oscilloscope.yaml"

# Open the Resource Manager with the simulation backend and config file
try:
    rm = pyvisa.ResourceManager(f'{sim_config}@sim')
except OSError as e:
    print(f"Failed to initialize ResourceManager with pyvisa-sim: {e}")
    exit()

# The VISA address from the YAML file
visa_address = 'USB::0x0461::0x0113::6062777::INSTR'

try:
    # Open the simulated instrument
    scope = rm.open_resource(visa_address)
    print(f"Successfully connected to simulated oscilloscope at {visa_address}")

    # --- FIX: Set a longer timeout for potentially slow operations ---
    # The default is 5000 ms. Increasing it gives the simulation time to respond.
    scope.timeout = 25000  # Set timeout to 25 seconds

    # Query identification string
    idn = scope.query("*IDN?")
    print(f"Instrument ID: {idn}")

    # Simulate basic oscilloscope setup and data acquisition
    print("Simulating data acquisition...")
    scope.write(":ACQUIRE:STATE ON")

    # Get scaling factors for the waveform
    y_mult = float(scope.query(":WFMOutpre:YMULT?"))
    y_offset = float(scope.query(":WFMOutpre:YOFF?"))
    x_incr = float(scope.query(":WFMOutpre:XINCR?"))
    
    print(f"Y Multiplier (Volts/Div): {y_mult}")
    print(f"Y Offset (Volts): {y_offset}")
    print(f"X Increment (Seconds): {x_incr}")

    # Get the simulated waveform data
    raw_data_str = scope.query(":CURVE?")
    raw_data = np.fromstring(raw_data_str, sep=',')

    # Scale the raw data to voltage and time values
    voltage = (raw_data * y_mult) + y_offset
    time = np.arange(0, len(voltage) * x_incr, x_incr)

    # Plot the simulated waveform
    plt.figure()
    plt.plot(time, voltage)
    plt.title("Simulated Oscilloscope Waveform")
    plt.xlabel("Time (s)")
    plt.ylabel("Voltage (V)")
    plt.grid(True)
    plt.show()

except pyvisa.VisaIOError as e:
    print(f"A VISA error occurred: {e}")
finally:
    if 'scope' in locals():
        scope.close()
    if 'rm' in locals():
        rm.close()
    print("Connection closed.")
