import pyvisa
import os

# Tell pyvisa-sim where to find the scope.yaml file
os.environ['PYVISA_SIM_FILE'] = './scope.yaml'

rm = pyvisa.ResourceManager('@sim')
resources = rm.list_resources()
print("Resources found:", resources)

inst = rm.open_resource('USB::12345678::INSTR')
print("Resource type:", type(inst))

# If query() works, use it
try:
    print("IDN:", inst.query("*IDN?"))
    print("Vpp:", inst.query("MEASUREMENT:IMMED:VALUE?"))
    print("Waveform:", inst.query("CURVE?"))
except AttributeError:
    # Fallback for older PyVISA
    inst.write("*IDN?")
    print("IDN:", inst.read())
    inst.write("MEASUREMENT:IMMED:VALUE?")
    print("Vpp:", inst.read())
    inst.write("CURVE?")
    print("Waveform:", inst.read())
