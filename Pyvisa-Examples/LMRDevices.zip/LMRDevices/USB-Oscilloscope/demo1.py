import pyvisa

rm = pyvisa.ResourceManager()

devices = rm.list_resources()

print("Connected Devices:",devices)

