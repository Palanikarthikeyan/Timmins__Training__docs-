import pyvisa
rm = pyvisa.ResourceManager('LMR_sim.yaml@sim')  
inst = rm.open_resource('GPIB::1::INSTR') 
inst.timeout=5000
# Use the resource name defined in your YAML
inst.read_termination = '\n'
inst.write_termination = '\n'
print(inst.query("*IDN?"))
