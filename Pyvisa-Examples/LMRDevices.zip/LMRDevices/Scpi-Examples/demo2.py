import pyvisa

rm = pyvisa.ResourceManager()
# Connect to SCPI simulator on localhost port 5025 (common for SCPI simulators)
instr = rm.open_resource('TCPIP0::127.0.0.1::5025::SOCKET')

print(instr.query("*IDN?"))

instr.write("VOLT 5")
print(instr.query("MEAS:VOLT?"))

instr.close()
