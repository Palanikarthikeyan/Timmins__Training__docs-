import pyvisa

# Initialize VISA resource manager
rm = pyvisa.ResourceManager()

# List all connected instruments
print(rm.list_resources())

# Connect to the instrument (example VISA address)
instr = rm.open_resource('USB0::0x0957::0x1796::MY12345678::INSTR')

# Ask for identification string (common SCPI command)
idn = instr.query("*IDN?")
print(f"Instrument ID: {idn}")

# Set a voltage on a power supply (example)
instr.write("VOLT 5")      # Set voltage to 5V
instr.write("CURR 1")      # Set current limit to 1A
instr.write("OUTP ON")     # Turn on output

# Measure voltage (example for a DMM)
voltage = instr.query("MEAS:VOLT?")
print(f"Measured Voltage: {voltage.strip()}")

# Close the connection
instr.close()
